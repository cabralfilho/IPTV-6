Lib7zS2 is a small and simple 7-Zip extraction library based on 7zS2 Sfx module 
from LZMA SDK http://www.7-zip.org/sdk.html

Lib7zS2.dll exports one function:

C++: int Extract7zW(const WCHAR *iArcPath, const WCHAR *iOutDirPath, HWND hPb)

PAS: function Extract7zW(iArcPath, iOutDirPath: PWideChar; hPb: Hwnd): integer; cdecl;

hPb is handle of ProgressBar, set to 0 if not needed

[IMPORTANT] use "cdecl", NOT "stdcall"!