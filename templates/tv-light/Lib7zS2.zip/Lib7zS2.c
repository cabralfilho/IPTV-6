/* Un7zMicro */

#ifndef _WINDOWS
#define _WINDOWS
#endif

#ifndef USE_WINDOWS_FILE
#define USE_WINDOWS_FILE
#endif

#ifndef _MBCS
#define _MBCS
#endif

#ifndef UNICODE
#define UNICODE
#endif

#ifndef _UNICODE
#define _UNICODE
#endif

#include "inc/7z.h"
#include "inc/7zAlloc.h"
#include "inc/7zCrc.h"
#include "inc/7zFile.h"
#include "inc/CpuArch.h"

#define kBufferSize (1 << 15)

#define kSignatureSearchLimit (1 << 22)

static Bool FindSignature(CSzFile *stream, UInt64 *resPos)
{
  Byte buf[kBufferSize];
  size_t numPrevBytes = 0;
  *resPos = 0;
  for (;;)
  {
    size_t numTests, pos;
    if (*resPos > kSignatureSearchLimit) return False;
    
    do
    {
      size_t processed = kBufferSize - numPrevBytes;
      if (File_Read(stream, buf + numPrevBytes, &processed) != 0)
        return False;
      if (processed == 0)
        return False;
      numPrevBytes += processed;
    }
    while (numPrevBytes <= k7zStartHeaderSize);
    
    numTests = numPrevBytes - k7zStartHeaderSize;
    for (pos = 0; pos < numTests; pos++)
    {
      for (; buf[pos] != '7' && pos < numTests; pos++);
      if (pos == numTests)
        break;
      if (memcmp(buf + pos, k7zSignature, k7zSignatureSize) == 0)
        if (CrcCalc(buf + pos + 12, 20) == GetUi32(buf + pos + 8))
        {
          *resPos += pos;
          return True;
        }
    }
    *resPos += numTests;
    numPrevBytes -= numTests;
    memmove(buf, buf + numTests, numPrevBytes);
  }
}

static Bool DoesFileOrDirExist(const WCHAR *path)
{
  WIN32_FIND_DATAW fd;
  HANDLE handle;
  handle = FindFirstFileW(path, &fd);
  if (handle == INVALID_HANDLE_VALUE)
    return False;
  FindClose(handle);
  return True;
}

extern __declspec(dllexport) int Extract7zW(const WCHAR *iArcPath, const WCHAR *iOutDirPath, HWND hPb)
{
  CFileInStream archiveStream;
  CLookToRead lookStream;
  CSzArEx db;
  SRes res = SZ_OK;
  ISzAlloc allocImp;
  ISzAlloc allocTempImp;
  WCHAR ArcPath[MAX_PATH + 2];
  WCHAR path[MAX_PATH * 3 + 2];
  size_t pathLen;

  CrcGenerateTable();

  allocImp.Alloc = SzAlloc;
  allocImp.Free = SzFree;

  allocTempImp.Alloc = SzAllocTemp;
  allocTempImp.Free = SzFreeTemp;

  FileInStream_CreateVTable(&archiveStream);
  LookToRead_CreateVTable(&lookStream, False);
 
  wcscpy(ArcPath,iArcPath);
  wcscpy(path,iOutDirPath);
  wcscat(path, L"\\");
  pathLen = wcslen(path);

  if (res != SZ_OK) return 1;

  if (InFile_OpenW(&archiveStream.file, ArcPath) != 0) res = SZ_ERROR_FAIL;
  else
  {
    UInt64 pos = 0;
    if (!FindSignature(&archiveStream.file, &pos)) res = SZ_ERROR_FAIL;
    else if (File_Seek(&archiveStream.file, (Int64 *)&pos, SZ_SEEK_SET) != 0) res = SZ_ERROR_FAIL;
    //if (res != 0) errorMessage = "Can't find 7z archive";
  }

  if (res == SZ_OK)
  {
    lookStream.realStream = &archiveStream.s;
    LookToRead_Init(&lookStream);
  }

  SzArEx_Init(&db);
  if (res == SZ_OK)
  {
    res = SzArEx_Open(&db, &lookStream.s, &allocImp, &allocTempImp);
  }
  if (res == SZ_OK)
  {
    UInt32 i;
    UInt32 blockIndex = 0xFFFFFFFF; /* it can have any value before first call (if outBuffer = 0) */
    Byte *outBuffer = 0; /* it must be 0 before first call for each new archive. */
    size_t outBufferSize = 0;  /* it can have any value before first call (if outBuffer = 0) */
    
    for (i = 0; i < db.db.NumFiles; i++)
    {
      size_t offset = 0;
      size_t outSizeProcessed = 0;
      const CSzFileItem *f = db.db.Files + i;
      size_t len;
      WCHAR *temp;

	  if (hPb > 0) SendMessage(hPb,1026,(SendMessage(hPb,1031,0,0)*i/db.db.NumFiles),0);

      len = SzArEx_GetFileNameUtf16(&db, i, NULL);
      
      if (len >= MAX_PATH)
      {
        res = SZ_ERROR_FAIL;
        break;
      }
      
      temp = path + pathLen;

      SzArEx_GetFileNameUtf16(&db, i, temp);
      {
        res = SzArEx_Extract(&db, &lookStream.s, i, &blockIndex, &outBuffer, &outBufferSize, &offset, &outSizeProcessed, &allocImp, &allocTempImp);
        if (res != SZ_OK) break;
      }
      {
        CSzFile outFile;
        size_t processedSize;
        size_t j;
        size_t nameStartPos = 0;
        for (j = 0; temp[j] != 0; j++)
        {
          if (temp[j] == '/')
          {
            temp[j] = 0;
            CreateDirectoryW(path, NULL) ? 0 : GetLastError();
            temp[j] = CHAR_PATH_SEPARATOR;
            nameStartPos = j + 1;
          }
        }

        if (f->IsDir)
        {
          CreateDirectoryW(path, NULL) ? 0 : GetLastError();
          continue;
        }
        else
        {
          const WCHAR *name = temp + nameStartPos;
          unsigned len = (unsigned)wcslen(name);
       
          if (OutFile_OpenW(&outFile, path))
          {
            res = SZ_ERROR_FAIL;
            break;
          }
        }
        processedSize = outSizeProcessed;
        if (File_Write(&outFile, outBuffer + offset, &processedSize) != 0 || processedSize != outSizeProcessed)
        {
          res = SZ_ERROR_FAIL;
        }
        
        #ifdef USE_WINDOWS_FILE
        if (f->MTimeDefined)
        {
          FILETIME mTime;
          mTime.dwLowDateTime = f->MTime.Low;
          mTime.dwHighDateTime = f->MTime.High;
          SetFileTime(outFile.handle, NULL, NULL, &mTime);
        }
        #endif
        
        {
          SRes res2 = File_Close(&outFile);
          if (res != SZ_OK) break;
          if (res2 != SZ_OK) { res = res2; break; }
        }

        #ifdef USE_WINDOWS_FILE
        if (f->AttribDefined) SetFileAttributesW(path, f->Attrib);
        #endif
      }
    }

    IAlloc_Free(&allocImp, outBuffer);
  }
  SzArEx_Free(&db, &allocImp);

  File_Close(&archiveStream.file);

  if (res == SZ_OK) return 0; else return res;
}


